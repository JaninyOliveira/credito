package com.wk.janiny.enumerator;

public enum Risco {
	A,B,C;
}
