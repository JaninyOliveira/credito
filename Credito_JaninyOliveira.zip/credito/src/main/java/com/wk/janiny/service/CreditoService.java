package com.wk.janiny.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wk.janiny.entity.ClienteCredito;
import com.wk.janiny.enumerator.Risco;
import com.wk.janiny.repository.CreditoRepository;

@Service
public class CreditoService {

	@Autowired
	private CreditoRepository creditoRepository;
	
	public void gravar(ClienteCredito clienteCredito) {
		if(Risco.A.equals(clienteCredito.getRisco())) {
			clienteCredito.setValorJuros(0D);
		}else if(Risco.B.equals(clienteCredito.getRisco())) {
			clienteCredito.setValorJuros(clienteCredito.getLimiteCredito()*0.10);
		}else {
			clienteCredito.setValorJuros(clienteCredito.getLimiteCredito()*0.20);
		}
		creditoRepository.save(clienteCredito);
	}

	public List<ClienteCredito> listarAll() {
		return creditoRepository.findAll();
	}

}
