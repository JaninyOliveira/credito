package com.wk.janiny.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.wk.janiny.entity.ClienteCredito;

@Repository
public interface CreditoRepository extends CrudRepository<ClienteCredito, Long> {

	List<ClienteCredito> findByNomeCliente(String nomeCliente);
	
	List<ClienteCredito> findAll();
}
