package com.wk.janiny.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wk.janiny.entity.ClienteCredito;
import com.wk.janiny.service.CreditoService;


@RestController
@RequestMapping("credito")
public class CreditoController {

	@Autowired
	private CreditoService creditoService;
	
	@PutMapping("/gravar")
	public void gravar(@RequestBody ClienteCredito clienteCredito) {
		creditoService.gravar(clienteCredito);
	}
	
	@GetMapping("/")
	public List<ClienteCredito> listarAll(){
		return creditoService.listarAll();
	}
}
