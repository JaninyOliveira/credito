package com.wk.janiny.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import com.wk.janiny.enumerator.Risco;

@Entity
@Table(name = "cliente_credito")
public class ClienteCredito {

	@Id
    @GeneratedValue
    @Column(name="id")
    private Long id;
	
	@Column(name="nome_cliente")
	private String nomeCliente;
	
	@Column(name="limite_credito")
	private Double limiteCredito;
	
	@Column(name="risco")
	private Risco risco;
	
	@Column(name="valor_juros")
	private Double valorJuros;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNomeCliente() {
		return nomeCliente;
	}

	public void setNomeCliente(String nomeCliente) {
		this.nomeCliente = nomeCliente;
	}

	public Double getLimiteCredito() {
		return limiteCredito;
	}

	public void setLimiteCredito(Double limiteCredito) {
		this.limiteCredito = limiteCredito;
	}

	public Risco getRisco() {
		return risco;
	}

	public void setRisco(Risco risco) {
		this.risco = risco;
	}

	public Double getValorJuros() {
		return valorJuros;
	}

	public void setValorJuros(Double valorJuros) {
		this.valorJuros = valorJuros;
	}
}
