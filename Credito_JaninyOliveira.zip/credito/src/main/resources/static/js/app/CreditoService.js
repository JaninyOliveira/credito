'use strict'
angular.module('credito.services', []).factory('CreditoService', ["$http", "CONSTANTS", function($http, CONSTANTS) {
    var service = {};
    service.getAllCreditos = function() {
        return $http.get(CONSTANTS.getAllCreditos);
    }
    service.saveCredito = function(clienteCredito) {
        return $http.put(CONSTANTS.saveCredito, clienteCredito);
    }
    return service;
}]);