'use strict'
var module = angular.module('credito.controllers', []);
module.controller("CreditoController", ["$scope", "CreditoService",
    function($scope, CreditoService) {
        $scope.clienteCredito = {
        	nomeCliente: null,
        	limiteCredito: null,
        	risco: null
        };
        $scope.saveCredito = function() {            
        	CreditoService.saveCredito($scope.clienteCredito).then(function() {
                console.log("works");
                CreditoService.getAllCreditos().then(function(value) {
                    $scope.allCreditos = value.data;
                }, function(reason) {
                    console.log("error occured");
                }, function(value) {
                    console.log("no callback");
                });
                $scope.clienteCredito = {
            		nomeCliente: null,
                	limiteCredito: null,
                	risco: null
                };
            }, function(reason) {
                console.log("error occured");
            }, function(value) {
                console.log("no callback");
            });
        }
    }
]);