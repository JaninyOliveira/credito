'use strict'
var creditoApp = angular.module('credito', ['ui.bootstrap', 'credito.controllers',
    'credito.services'
]);
creditoApp.constant("CONSTANTS", {
    getAllCreditos: "/credito/",
    saveCredito: "/credito/gravar"
});